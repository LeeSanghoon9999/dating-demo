"use strict";
exports.id = 614;
exports.ids = [614];
exports.modules = {

/***/ 3614:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _stackflow_plugin_preload__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3547);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_FeedCard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5265);
/* harmony import */ var _lib_readPageProps__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2593);
/* harmony import */ var _AppLayout__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6104);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_stackflow_plugin_preload__WEBPACK_IMPORTED_MODULE_0__, _components_FeedCard__WEBPACK_IMPORTED_MODULE_2__, _AppLayout__WEBPACK_IMPORTED_MODULE_4__]);
([_stackflow_plugin_preload__WEBPACK_IMPORTED_MODULE_0__, _components_FeedCard__WEBPACK_IMPORTED_MODULE_2__, _AppLayout__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const My = () => {
  // ✅ Next.js 방식에서는 preloadRef로부터 props를 가져올 때 readPageProps 활용
  const preloadRef = (0,_stackflow_plugin_preload__WEBPACK_IMPORTED_MODULE_0__.useActivityPreloadRef)();
  const pageProps = (0,_lib_readPageProps__WEBPACK_IMPORTED_MODULE_3__/* .readPageProps */ .o)(preloadRef);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_AppLayout__WEBPACK_IMPORTED_MODULE_4__["default"], {
    children: pageProps?.articles?.map(article => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_FeedCard__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
      articleId: article.articleId,
      daysAgo: article.daysAgo,
      price: article.price,
      region: article.region,
      title: article.title
    }, article.articleId)) || /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("div", {
      children: "Loading..."
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (My);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;