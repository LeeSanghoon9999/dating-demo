"use strict";
exports.id = 40;
exports.ids = [40];
exports.modules = {

/***/ 4040:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "body": () => (/* binding */ body),
/* harmony export */   "container": () => (/* binding */ container),
/* harmony export */   "content": () => (/* binding */ content),
/* harmony export */   "image": () => (/* binding */ image),
/* harmony export */   "imageInner": () => (/* binding */ imageInner),
/* harmony export */   "recommenderGrid": () => (/* binding */ recommenderGrid),
/* harmony export */   "section": () => (/* binding */ section),
/* harmony export */   "sectionTitle": () => (/* binding */ sectionTitle),
/* harmony export */   "subtitle": () => (/* binding */ subtitle),
/* harmony export */   "title": () => (/* binding */ title)
/* harmony export */ });
/* harmony import */ var src_styles_f_css_ts_vanilla_css_node_modules_vanilla_extract_webpack_plugin_virtualFileLoader_dist_vanilla_extract_webpack_plugin_virtualFileLoader_cjs_js_fileName_src_styles_f_css_ts_vanilla_css_source_H4sIAAAAAAAAE5WTwW7bMAyG73kKXQqkQBU467Ku7tPQFm0zliVDkuMGQ9_9lJQmSrfLgPgQ8iP565e4W6cR8ViJPxshFPlZw7kWvSP1tvnY7HJ2f5_tNL4X2R8pC5p6Iyng5GvRognoCuY5McfFB_rOsrWcNuEf3M_ExQFSkcM2kDWMWb1MpsAOV6wW_yL_K8Vn6ykXQuO5NGCBvHxDHGoIdCqR3wkJdq5FVYRfU1hjF_7jkOIrqTCwmqp6KHJNyg1I_RD_SqpcOLBp0s_QYi2MXR3MBYPZ3HlGcGAyYlisEI11Cl2SwucBpcj0l38NtGPv7GLUDWcPLdMncFspPaKSvgWNMsVl7_AsX6vqMaIB34NM91mn4xZyuiTnf3spbK2D7HfWc23Y54aL87HjbCk_CCHkis1IQQaY5cD26WihvEwO7AU75vj5FL2G1Mue0HXarrUYSCk0SUXkO_umSylfOT6rbfUk4i8JncCPkibo2eKv2Q4UgY4HUsSjtumqnkSj2d_HYjDdDZa8Ir51VuvyHNdsTqXLCnZph7JPXX_hmWrA3a_eN_eO_UmSQXl9Y7v9oSDGLK058i7JjuLORSVvt_BtFQ7VQ_y4_hN2Gt3dFgQAAA_node_modules_vanilla_extract_webpack_plugin_extracted_dist_vanilla_extract_webpack_plugin_extracted_cjs_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9089);
/* harmony import */ var src_activities_Article_css_ts_vanilla_css_node_modules_vanilla_extract_webpack_plugin_virtualFileLoader_dist_vanilla_extract_webpack_plugin_virtualFileLoader_cjs_js_fileName_src_activities_Article_css_ts_vanilla_css_source_LmQ2bzB2eTEgewogIHdpZHRoOiAxMDAlOwogIGhlaWdodDogMDsKICBwYWRkaW5nLWJvdHRvbTogMTAwJTsKICBiYWNrZ3JvdW5kOiB2YXIoLS1zZWVkLXNjYWxlLWNvbG9yLWdyYXktMTAwKTsKfQouZDZvMHZ5MyB7CiAgbWFyZ2luOiAxLjVyZW0gMXJlbSAwOwogIHBhZGRpbmctYm90dG9tOiAwLjI1cmVtOwogIGJveC1zaGFkb3c6IDAgMXB4IDAgMCB2YXIoLS1zZWVkLXNlbWFudGljLWNvbG9yLWRpdmlkZXItMSk7Cn0KLmQ2bzB2eTQgewogIGZvbnQtc2l6ZTogMS4yNXJlbTsKICBmb250LXdlaWdodDogYm9sZDsKICBtYXJnaW4tYm90dG9tOiAuNjI1cmVtOwp9Ci5kNm8wdnk1IHsKICBmb250LXNpemU6IC44MTI1cmVtOwogIGNvbG9yOiB2YXIoLS1zZWVkLXNjYWxlLWNvbG9yLWdyYXktNjAwKTsKICBtYXJnaW4tYm90dG9tOiAxcmVtOwp9Ci5kNm8wdnk2IHsKICBmb250LXNpemU6IDFyZW07CiAgbGluZS1oZWlnaHQ6IDEuMzc1cmVtOwogIG1hcmdpbi1ib3R0b206IDEuMjVyZW07Cn0KLmQ2bzB2eTcgewogIGJveC1zaGFkb3c6IDAgMXB4IDAgMCB2YXIoLS1zZWVkLXNlbWFudGljLWNvbG9yLWRpdmlkZXItMSk7Cn0KLmQ2bzB2eTc6bGFzdC1jaGlsZCB7CiAgYm94LXNoYWRvdzogbm9uZTsKfQouZDZvMHZ5OCB7CiAgcGFkZGluZzogMS4yNXJlbSAxcmVtOwogIGZvbnQtc2l6ZTogMXJlbTsKICBmb250LXdlaWdodDogYm9sZDsKfQouZDZvMHZ5OSB7CiAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiAxZnIgMWZyOwogIHBhZGRpbmc6IC4yNXJlbSAxcmVtIDFyZW07CiAgZ2FwOiAxLjI1cmVtOwp9_node_modules_vanilla_extract_webpack_plugin_extracted_dist_vanilla_extract_webpack_plugin_extracted_cjs_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5759);


var body = 'd6o0vy6';
var container = 'wmkeej6 wmkeej8 wmkeej9 wmkeeja wmkeejb wmkeeji wmkeejj';
var content = 'd6o0vy3';
var image = 'd6o0vy1 wmkeej7';
var imageInner = 'wmkeej6 wmkeej8 wmkeej9 wmkeeja wmkeejb';
var recommenderGrid = 'd6o0vy9 wmkeej0';
var section = 'd6o0vy7';
var sectionTitle = 'd6o0vy8';
var subtitle = 'd6o0vy5';
var title = 'd6o0vy4';

/***/ }),

/***/ 5759:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var _next_dist_build_webpack_loaders_css_loader_src_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2681);
/* harmony import */ var _next_dist_build_webpack_loaders_css_loader_src_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_next_dist_build_webpack_loaders_css_loader_src_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _next_dist_build_webpack_loaders_css_loader_src_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(false);
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".d6o0vy1 {\n  width: 100%;\n  height: 0;\n  padding-bottom: 100%;\n  background: var(--seed-scale-color-gray-100);\n}\n.d6o0vy3 {\n  margin: 1.5rem 1rem 0;\n  padding-bottom: 0.25rem;\n  box-shadow: 0 1px 0 0 var(--seed-semantic-color-divider-1);\n}\n.d6o0vy4 {\n  font-size: 1.25rem;\n  font-weight: bold;\n  margin-bottom: .625rem;\n}\n.d6o0vy5 {\n  font-size: .8125rem;\n  color: var(--seed-scale-color-gray-600);\n  margin-bottom: 1rem;\n}\n.d6o0vy6 {\n  font-size: 1rem;\n  line-height: 1.375rem;\n  margin-bottom: 1.25rem;\n}\n.d6o0vy7 {\n  box-shadow: 0 1px 0 0 var(--seed-semantic-color-divider-1);\n}\n.d6o0vy7:last-child {\n  box-shadow: none;\n}\n.d6o0vy8 {\n  padding: 1.25rem 1rem;\n  font-size: 1rem;\n  font-weight: bold;\n}\n.d6o0vy9 {\n  grid-template-columns: 1fr 1fr;\n  padding: .25rem 1rem 1rem;\n  gap: 1.25rem;\n}", ""]);
// Exports
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (___CSS_LOADER_EXPORT___)));


/***/ })

};
;