"use strict";
exports.id = 501;
exports.ids = [501];
exports.modules = {

/***/ 7501:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _stackflow_plugin_preload__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3547);
/* harmony import */ var _stackflow_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1213);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_FeedCard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5265);
/* harmony import */ var _components_MapLoading__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6980);
/* harmony import */ var _lib_readPageProps__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2593);
/* harmony import */ var _AppLayout__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6104);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_stackflow_plugin_preload__WEBPACK_IMPORTED_MODULE_0__, _stackflow_react__WEBPACK_IMPORTED_MODULE_1__, _components_FeedCard__WEBPACK_IMPORTED_MODULE_3__, _AppLayout__WEBPACK_IMPORTED_MODULE_6__]);
([_stackflow_plugin_preload__WEBPACK_IMPORTED_MODULE_0__, _stackflow_react__WEBPACK_IMPORTED_MODULE_1__, _components_FeedCard__WEBPACK_IMPORTED_MODULE_3__, _AppLayout__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









// 기본 서울 좌표
const defaultCenter = {
  lat: 37.5665,
  lng: 126.9780
};

const MapTab = () => {
  // Main에서 준비한 페이지 프롭스를 재사용 (공통 키 "Main" 사용)
  const preloadRef = (0,_stackflow_plugin_preload__WEBPACK_IMPORTED_MODULE_0__.useActivityPreloadRef)();
  const pageProps = (0,_lib_readPageProps__WEBPACK_IMPORTED_MODULE_5__/* .readPageProps */ .o)(preloadRef); // URL 파라미터로 전달된 lat, lng는 문자열이므로 숫자로 파싱

  const {
    lat,
    lng
  } = (0,_stackflow_react__WEBPACK_IMPORTED_MODULE_1__.useActivityParams)(); // 초기 위치: sessionStorage에서 읽어오거나, URL 파라미터가 있으면 사용

  const getInitialLocation = () => {
    if (false) {}

    if (lat !== undefined && lng !== undefined) {
      return {
        lat: parseFloat(lat),
        lng: parseFloat(lng)
      };
    }

    return null;
  };

  const {
    0: userLocation,
    1: setUserLocation
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(getInitialLocation()); // 만약 컴포넌트 마운트 후에 sessionStorage가 변경되었을 경우 업데이트

  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
    const stored = sessionStorage.getItem("userLocation");

    if (stored) {
      setUserLocation(JSON.parse(stored));
    }
  }, []);

  const handleFindMyLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(position => {
        const loc = {
          lat: position.coords.latitude,
          lng: position.coords.longitude
        };
        setUserLocation(loc);
        sessionStorage.setItem("userLocation", JSON.stringify(loc));
      }, error => {
        console.error("현재 위치를 가져오는데 실패했습니다.", error);
      });
    } else {
      console.error("이 브라우저는 Geolocation을 지원하지 않습니다.");
    }
  };

  const mapCenterValue = userLocation || defaultCenter;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)(_AppLayout__WEBPACK_IMPORTED_MODULE_6__["default"], {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_components_MapLoading__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
      center: mapCenterValue,
      userLocation: userLocation
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("button", {
      type: "button",
      onClick: handleFindMyLocation,
      style: {
        margin: "1rem",
        padding: "0.5rem 1rem",
        borderRadius: "4px",
        border: "none",
        backgroundColor: "#007bff",
        color: "#fff",
        cursor: "pointer"
      },
      children: "\uB0B4 \uC704\uCE58 \uCC3E\uAE30"
    }), pageProps?.articles?.map(article => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_components_FeedCard__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
      articleId: article.articleId,
      daysAgo: article.daysAgo,
      price: article.price,
      region: article.region,
      title: article.title
    }, article.articleId)) || /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
      children: "Loading..."
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MapTab);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6980:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _react_google_maps_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2433);
/* harmony import */ var _react_google_maps_api__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);





function MapLoading({
  center,
  userLocation
}) {
  const {
    isLoaded
  } = (0,_react_google_maps_api__WEBPACK_IMPORTED_MODULE_0__.useJsApiLoader)({
    id: "google-map-script",
    googleMapsApiKey: "AIzaSyD5m_Luc1EQB604BRDoNwTosiu6HTTePgE" || 0
  });

  if (!isLoaded) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
      children: "\uC9C0\uB3C4 \uB85C\uB529 \uC911..."
    });
  } // 위도 1도는 대략 111km


  const latDelta = 3 / 111; // 약 0.027도
  // 경도 델타는 위도에 따라 달라짐 (cos 함수를 사용)

  const lngDelta = 3 / (111 * Math.cos(center.lat * (Math.PI / 180)));
  const bounds = {
    north: center.lat + latDelta,
    south: center.lat - latDelta,
    east: center.lng + lngDelta,
    west: center.lng - lngDelta
  };
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_0__.GoogleMap, {
    mapContainerStyle: {
      width: "100%",
      height: "400px"
    },
    center: center,
    zoom: 14 // 대략 3km 반경에 맞는 줌 레벨
    ,
    options: {
      restriction: {
        latLngBounds: bounds,
        strictBounds: false
      }
    },
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_0__.Marker, {
      position: center
    }), userLocation && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_0__.Marker, {
      position: userLocation
    })]
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MapLoading);

/***/ })

};
;