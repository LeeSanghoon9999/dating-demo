"use strict";
exports.id = 265;
exports.ids = [265];
exports.modules = {

/***/ 268:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F2": () => (/* binding */ right),
/* harmony export */   "LI": () => (/* binding */ button),
/* harmony export */   "Oc": () => (/* binding */ subtitle),
/* harmony export */   "Q1": () => (/* binding */ thumbnail),
/* harmony export */   "TN": () => (/* binding */ title),
/* harmony export */   "nC": () => (/* binding */ container),
/* harmony export */   "nt": () => (/* binding */ price)
/* harmony export */ });
/* harmony import */ var src_styles_f_css_ts_vanilla_css_node_modules_vanilla_extract_webpack_plugin_virtualFileLoader_dist_vanilla_extract_webpack_plugin_virtualFileLoader_cjs_js_fileName_src_styles_f_css_ts_vanilla_css_source_H4sIAAAAAAAAE5WTwW7bMAyG73kKXQqkQBU467Ku7tPQFm0zliVDkuMGQ9_9lJQmSrfLgPgQ8iP565e4W6cR8ViJPxshFPlZw7kWvSP1tvnY7HJ2f5_tNL4X2R8pC5p6Iyng5GvRognoCuY5McfFB_rOsrWcNuEf3M_ExQFSkcM2kDWMWb1MpsAOV6wW_yL_K8Vn6ykXQuO5NGCBvHxDHGoIdCqR3wkJdq5FVYRfU1hjF_7jkOIrqTCwmqp6KHJNyg1I_RD_SqpcOLBp0s_QYi2MXR3MBYPZ3HlGcGAyYlisEI11Cl2SwucBpcj0l38NtGPv7GLUDWcPLdMncFspPaKSvgWNMsVl7_AsX6vqMaIB34NM91mn4xZyuiTnf3spbK2D7HfWc23Y54aL87HjbCk_CCHkis1IQQaY5cD26WihvEwO7AU75vj5FL2G1Mue0HXarrUYSCk0SUXkO_umSylfOT6rbfUk4i8JncCPkibo2eKv2Q4UgY4HUsSjtumqnkSj2d_HYjDdDZa8Ir51VuvyHNdsTqXLCnZph7JPXX_hmWrA3a_eN_eO_UmSQXl9Y7v9oSDGLK058i7JjuLORSVvt_BtFQ7VQ_y4_hN2Gt3dFgQAAA_node_modules_vanilla_extract_webpack_plugin_extracted_dist_vanilla_extract_webpack_plugin_extracted_cjs_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9089);
/* harmony import */ var src_components_FeedCard_css_ts_vanilla_css_node_modules_vanilla_extract_webpack_plugin_virtualFileLoader_dist_vanilla_extract_webpack_plugin_virtualFileLoader_cjs_js_fileName_src_components_FeedCard_css_ts_vanilla_css_source_Ll8xZnRuaGZvMCB7CiAgcGFkZGluZzogMXJlbSAxcmVtIDA7Cn0KLl8xZnRuaGZvMSB7CiAgYm94LXNoYWRvdzogMCAxcHggMCAwIHZhcigtLXNlZWQtc2VtYW50aWMtY29sb3ItZGl2aWRlci0xKTsKICBwYWRkaW5nLWJvdHRvbTogMXJlbTsKICB3aWR0aDogMTAwJTsKfQouXzFmdG5oZm8yIHsKICB3aWR0aDogNi43NXJlbTsKICBoZWlnaHQ6IDYuNzVyZW07CiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tc2VlZC1zY2FsZS1jb2xvci1ncmF5LTEwMCk7CiAgYm9yZGVyLXJhZGl1czogLjM3NXJlbTsKICBtYXJnaW4tcmlnaHQ6IDFyZW07CiAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjsKICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiA1MCUgNTAlOwp9Ci5fMWZ0bmhmbzQgewogIGZvbnQtc2l6ZTogMXJlbTsKICBsaW5lLWhlaWdodDogMS4zNzVyZW07Cn0KLl8xZnRuaGZvNSB7CiAgZm9udC1zaXplOiAuODEyNXJlbTsKICBsaW5lLWhlaWdodDogMS4yNXJlbTsKICBjb2xvcjogdmFyKC0tc2VlZC1zY2FsZS1jb2xvci1ncmF5LTYwMCk7Cn0KLl8xZnRuaGZvNiB7CiAgZm9udC1zaXplOiAuODc1cmVtOwogIGZvbnQtd2VpZ2h0OiBib2xkOwogIGxpbmUtaGVpZ2h0OiAxLjI1cmVtOwp9_node_modules_vanilla_extract_webpack_plugin_extracted_dist_vanilla_extract_webpack_plugin_extracted_cjs_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2227);


var button = '_1ftnhfo1 wmkeejg wmkeejf wmkeej1';
var container = '_1ftnhfo0 wmkeej1';
var price = '_1ftnhfo6';
var right = 'wmkeej5';
var subtitle = '_1ftnhfo5';
var thumbnail = '_1ftnhfo2 wmkeejh';
var title = '_1ftnhfo4';

/***/ }),

/***/ 5265:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9252);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lib_Link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3136);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3039);
/* harmony import */ var _FeedCard_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(268);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_Link__WEBPACK_IMPORTED_MODULE_2__]);
_lib_Link__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








const FeedCard = ({
  articleId,
  title,
  price,
  region,
  daysAgo
}) => {
  const imageUrl = `https://picsum.photos/800/800/?id=${articleId}`;
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("div", {
    className: _FeedCard_css__WEBPACK_IMPORTED_MODULE_4__/* .container */ .nC,
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(_lib_Link__WEBPACK_IMPORTED_MODULE_2__/* .Link */ .r, {
      className: _FeedCard_css__WEBPACK_IMPORTED_MODULE_4__/* .button */ .LI,
      activityName: "Article",
      activityParams: {
        articleId: String(articleId)
      },
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("div", {
        className: _FeedCard_css__WEBPACK_IMPORTED_MODULE_4__/* .thumbnail */ .Q1,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_1__.LazyLoadImage, {
          className: _styles__WEBPACK_IMPORTED_MODULE_3__/* .f.imgObjectFitCover */ .f.zG,
          src: imageUrl,
          effect: "opacity",
          width: 108,
          height: 108
        })
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
        className: _FeedCard_css__WEBPACK_IMPORTED_MODULE_4__/* .right */ .F2,
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("div", {
          className: _FeedCard_css__WEBPACK_IMPORTED_MODULE_4__/* .title */ .TN,
          children: title
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
          className: _FeedCard_css__WEBPACK_IMPORTED_MODULE_4__/* .subtitle */ .Oc,
          children: [region, " \xB7 ", daysAgo, " day ago"]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
          className: _FeedCard_css__WEBPACK_IMPORTED_MODULE_4__/* .price */ .nt,
          children: ["\xA3", price, ".00"]
        })]
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FeedCard);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3136:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* binding */ Link)
/* harmony export */ });
/* harmony import */ var _stackflow_link__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7814);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_stackflow_link__WEBPACK_IMPORTED_MODULE_0__]);
_stackflow_link__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const {
  Link
} = (0,_stackflow_link__WEBPACK_IMPORTED_MODULE_0__.createLinkComponent)();
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2227:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var _next_dist_build_webpack_loaders_css_loader_src_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2681);
/* harmony import */ var _next_dist_build_webpack_loaders_css_loader_src_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_next_dist_build_webpack_loaders_css_loader_src_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _next_dist_build_webpack_loaders_css_loader_src_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(false);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "._1ftnhfo0 {\n  padding: 1rem 1rem 0;\n}\n._1ftnhfo1 {\n  box-shadow: 0 1px 0 0 var(--seed-semantic-color-divider-1);\n  padding-bottom: 1rem;\n  width: 100%;\n}\n._1ftnhfo2 {\n  width: 6.75rem;\n  height: 6.75rem;\n  background-color: var(--seed-scale-color-gray-100);\n  border-radius: .375rem;\n  margin-right: 1rem;\n  background-size: cover;\n  background-position: 50% 50%;\n}\n._1ftnhfo4 {\n  font-size: 1rem;\n  line-height: 1.375rem;\n}\n._1ftnhfo5 {\n  font-size: .8125rem;\n  line-height: 1.25rem;\n  color: var(--seed-scale-color-gray-600);\n}\n._1ftnhfo6 {\n  font-size: .875rem;\n  font-weight: bold;\n  line-height: 1.25rem;\n}", ""]);
// Exports
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (___CSS_LOADER_EXPORT___)));


/***/ })

};
;